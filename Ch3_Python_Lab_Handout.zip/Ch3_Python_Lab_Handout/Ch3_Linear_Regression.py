
# coding: utf-8

# # Chapter 3 - Linear Regression
# 
# ISLR 3장의 Linear Regression Python으로 실습. 
# 
# ## 사용할 주요 Python 패키지
# - [pandas](http://pandas.pydata.org)  : 데이터 Munging
# - [numpy](http://www.numpy.org/)  : 수식 계산 
# - [matplotlib](http://matplotlib.org/)  : 시각화 
# - [seaborn](http://stanford.edu/~mwaskom/software/seaborn/#)  : 시각화 
# - [statsmodels](http://statsmodels.sourceforge.net/)  : 통계모델
# - [scikit-learn](http://scikit-learn.org/stable)  : 머신러닝 

# In[41]:

# 패키지 imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn
import statsmodels.formula.api as smf
import sklearn.linear_model as skl_lm
from sklearn import datasets

# from myutil import st         
# from corrplot import Corrplot

# notebook에 직접 그래프를 plot  
get_ipython().magic('matplotlib inline')


# ## Data Load
# 
# - 책에서 사용한 **Advertising** 데이터를 load 함. 
# - local 에서 로딩할 수도, 또는 웹에서 직접 갖고 올 수도 있다. 로딩하기 전에 데이터 구조를 잘 이해하도록 

# In[42]:

# read data directly from Web as DataFrame 
advertising = pd.read_csv('http://www-bcf.usc.edu/~gareth/ISL/Advertising.csv', index_col=0)

# or, read data as DataFrame from local machine.  'Data' is sub directory this this working directory 
# advertising = pd.read_csv('Data/Advertising.csv', usecols=[1,2,3,4])
advertising.head()


# In[43]:

type(advertising)


# In[44]:

advertising.shape


# 200 개의 레코드/observation이 있음. Feature/predictor는 4 가지 

# In[45]:

advertising.info()     # works similar to R's 'str' function for DataFrame


# 데이터에 대한 자세한 정보 제공 : 타입, shape, 각 feature/column의 속성   
# - **자주 사용하기 바람**

# In[46]:

# seaborne 패키지를 이용해 feature들의 scatter plot을 본다  
seaborn.pairplot(advertising)


# - 마지막 행 Sales를 보니, Sales와 TV가 ***정비례*** 함을 볼 수 있음 

# ## Simple Linear Regression
# 
# $Y = \beta_0 + \beta_1X$
# 
# - $Y$ : response/output/target 
# - $X$ : feature/input/predictor
# - $\beta_0$ is the intercept
# - $\beta_1$ is the coefficient for $X$
# 
# $\beta_0$ 와 $\beta_1$ 을 묶어 **model coefficients** 라 함 

# ### Estimating the Coefficients ###
# ***Statsmodels*** 을 사용해 **advertising** 데이터에 대한 linear regression 모델의 coefficient 추정
# - ### [statsmodels version 0.5](http://statsmodels.sourceforge.net/stable/example_formulas.html) 에서 R 스타일 formula 도입  

# In[47]:

# 앞에서 아래와 같이 R style formula load 했음 
# import statsmodels.formula.api as smf

# ordinary least squares (ols) 방식 linear regression 모델 만들기 
lm = smf.ols(formula='Sales ~ TV', data=advertising).fit()

# coefficients
lm.params

# lm.pvalues            # p values
# lm.rsquared           # R-squared statistic 


# #### 위에서 만든 'lm'  linear regression 모델은 단 1개의 predictor 'TV' 만을 사용해 response인 'Sales'를 예측하려 하기에 ***Simple Regression***

# In[48]:

# 모델에 쓰인 데이터의 scatter plot과 모델의 결과를 plot 
plt.scatter(advertising.TV, advertising.Sales)
plt.xlabel("TV (in 1000's)")
plt.ylabel("Sales (in 1000's)")

X = pd.DataFrame({'TV':[advertising.TV.min(), advertising.TV.max()]})
Y = lm.predict(X)
plt.plot(X, Y, c='red')
plt.title("Simple Linar Regression")


# In[49]:

# seaborn 패키지를 이용할 수도 
seaborn.regplot(advertising.TV, advertising.Sales, order=1, ci=None, scatter_kws={'color':'r'})
plt.xlim(-50,350)
plt.ylim(ymin=0);


# In[50]:

lm.summary()     #  모델 전체 요약. R 결과와 유사하나 정보가 더 많음. 


# In[51]:

# Table 3.1
lm.summary().tables[1]


# ## Prediction
# - 위에서 Advertising의 모든 데이터를 사용해 모델을 만들었음
# - 위의 R-squared 값 0.612 는 이 모델을 만들 때 사용한 데이터를 대상으로 구한 값이지, test data로 구한 것 아님
# 
# #### 이 모델 (lm)을 이용해 새로운 predictor 값 (TV)을 줄 때 'Sales' 예측은? 
# - 가령, TV = 100 일 때 Sales 예측은?

# In[52]:

# statsmodel formula 인터페이스는 입력을 pandas의 DataFrame으로 해야...
x_new = pd.DataFrame({'TV': [100]})    # dictionary로 df를 만드는 일반 방법 
# x_new.info()
x_new.head()


# In[53]:

lm.predict(x_new)[0]    # 예측치를 numpy의 ndarray로 반환 


# ### 손으로 계산하여 확인 
# $$y = \beta_0 + \beta_1x$$
# $$y = 7.0326 + 0.0475 \times x$$

# In[54]:

sales_manual = lm.params.Intercept + lm.params.TV * 100
print("Manual Calculation : %6f" % sales_manual)


# In[55]:

X_new = pd.DataFrame({'TV': [100, 422, 74]})
lm.predict(X_new)


# 
# 
# 
# # Multiple Linear Regression
# 
# **multiple linear regression**: 여러개 feature
# 
# $Y = \beta_0 + \beta_1X_1 + ... + \beta_nX_n$
# 
# ***Advertising***의 TV, Radio, Newspaper들을 feature로 하고, Sales를 response로 한 multiple linear regression :
# 
# $Sales = \beta_0 + \beta_1 \times TV + \beta_2 \times Radio + \beta_3 \times Newspaper$
# 

# In[56]:

lm_mul = smf.ols(formula='Sales ~ TV + Radio + Newspaper', data=advertising).fit()
lm_mul.summary()


# - F statistic의 p-value가 매우 작으므로 (1.58e-96) 이 모델은 유효 (최소한 1개 이상의 variable이 response와 연관)
# - TV와 Radio의 p-value는 의미있음.  하지만 Newspaper의 p-value는 0.86에 달하므로 "Newspaper가 response와 관련이 없다"라는 null-hypothesis를 거부할 수 없음. 따라서 Newspaper 변수를 모델에 포함하기에는 적합하지 않음 
# - **R-squared** simple linear regression (0.612) 때보다 증가. 이 모델이 이전 simple linear regression 보다 response를 더 잘 설명(예측)한다고 생각할 수 있음. 
# - 주의: 이 R-squared는 모델을 만들 때 데이터 (즉, training set에)에 대해서 구한 것이기에 실제 환경에서도 (out-of-sample) 더 좋은 특성을 보이는 지는 확신할 수 없음 
# - **Cross-validation**을 통해 모델이 **out-of-sample**에 대해서도 **generalize** 잘 할 것 같은가 좀 더 신뢰성있게 알아 볼 수 있음 

# In[57]:

lm_mul.summary().tables[1]               # Table 3.4 of ISLR 


# In[58]:

advertising.corr()     # Table 3.5 of ISLR : correlation matrix (상관 관계)


# ## 3.3   Other Considerations in the Regression Model
# 
# ### Qualitative Predictors

# In[59]:

# Load 'credit' data from local folder
credit = pd.read_csv('Data/Credit.csv', usecols=list(range(1,12)))
credit.info()
credit.head(3)


# Feature중 Gender, Student, Married, Ethnicity 변수가 qualitative(categorical) 변수 

# In[60]:

seaborn.pairplot(credit[['Balance','Age','Cards','Education','Income','Limit','Rating']])  # Fig 3.6


# In[61]:

credit.Gender.unique()               # Gender 변수는 단 2개의 category(level)를 지님   


# In[62]:

lm_cat = smf.ols(formula='Balance ~ Gender', data=credit).fit()   # Gender has 2 levels -> 1 dummy variable
lm_cat.summary().tables[1]          # Table 3.7  


# In[63]:

# Regression of Balance onto Ethnicity
lm_cat_Eth = smf.ols('Balance ~ Ethnicity', credit).fit()
lm_cat_Eth.summary()            # Table 3.8 


# - F-statistic p-value가 0.957에 달해 'Balance와 Ethnicity간 관련이 없다'는 null hypothesis를 거부할 수 없기에 이 데이터에 따르면 null hypothesis를 따른는 것이 좋다.  즉, 이 모델은  **꽝!**

# In[64]:

features = list(credit.columns) ; features.remove('Ethnicity') ; features


# In[65]:

lm_all = smf.ols('Balance ~ Income + Limit + Age + Education + Married + Gender + Cards', credit).fit()
lm_all.summary()


# 
# ## Removing the Additive Assumptions : 변수간 Interaction 

# In[66]:

lm_interact = smf.ols('Sales ~ TV + Radio + TV:Radio', advertising).fit()
lm_interact.summary().tables[1]             # Table 3.9


# In[67]:

smf.ols('Sales ~ TV*Radio', advertising).fit().summary().tables[1]      # 위와 같은 결과 


# In[68]:

smf.ols('Sales ~ TV + Newspaper*Radio', advertising).fit().summary()


# 
# ### Interaction between qualitative variable and a quantitative variable

# In[69]:

# No interaction between Income(quantitative) & Studen(qualitative with 2 levels)
lm_no_interact = smf.ols('Balance ~ Income  + Student', credit).fit()   
lm_no_interact.summary()


# In[70]:

# Interaction between Income(quantitative) & Studen(qualitative with 2 levels)
lm_interact = smf.ols('Balance ~ Income*Student', credit).fit()
lm_interact.summary()


# 
# ### Non-linear relationships using polynomial regressions

# In[71]:

# load auto data
auto = pd.read_csv('Data/Auto.csv')
auto.info()
auto.head()


# **(중요) horsepower 변수가 숫자이어야 함. 그런데, 위의 auto.info()로 본 horsepower 변수 타입이 'object'로 되어 있음.  즉 숫자가 아니라고 함.  auto.head()로 보니 처음에는 분명 숫자.  따라서 horsepower 변수 중간 어디 즈음 숫자가 아닌 것이 있음 **

# In[72]:

# Find out what rows have non-numeric value on 'horsepower'
auto_problem = auto[auto.horsepower.apply(lambda x: not(x.isnumeric()))]
auto_problem


# OK. found them.  원래 auto.csv 를 보니 역시 위와 같음 
# - 위의 row들을 제거할 수도 있고, 또는 파일을 읽을 때 위 문제가 있는 row들을 제거하고 읽을 수도.

# In[73]:

# Read the data again. This time correctly
auto = pd.read_csv('Data/Auto.csv', na_values='?').dropna()
auto.info()
auto.iloc[28: 34, :]


# 문제있는 row들 제거 확인

# 
# ### mpg를 $horsepower$ 와  $horsepower^2$ 에 대해 regression 

# In[74]:

# OLS regression of mpg onto horsepower and squared(horsepower)
lm_quadratic = smf.ols('mpg ~ horsepower + np.square(horsepower)', data=auto).fit()
lm_quadratic.summary().tables[1]             # Table 3.10


# In[75]:

# Polynomial regression upto 3'rd degree 
lm_deg3 = smf.ols('mpg ~ horsepower + np.power(horsepower,2) +  np.power(horsepower,3)', data=auto).fit()
lm_deg3.summary()


# # 숙제 : 다음 주 까지
# 
# ## 책의 3.6.2 ~ 3.6.6 에 Boston 데이타와 Carseats 데이터를 이용한 실습이 있음.  책은 R을 이용한 것이나, 본 실습에서 본 것과 같이 Python도 매우 비슷함.  본 실습에서 3.6.2 ~ 3.6.6 에서 하는 모든 분석을 다루었음
# 
# ## 할 일 : Python으로 3.6.2 ~ 3.6.6 과정을 묘사함.  단, 책에 있는 plotting, anova와 같이 강의에서 다루지 않은 과정은 패스.  자세한 것은 강의에서..
